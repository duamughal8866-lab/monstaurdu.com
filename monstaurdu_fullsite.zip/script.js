let videos = JSON.parse(localStorage.getItem('videos')) || [];
let posts = JSON.parse(localStorage.getItem('posts')) || [];

const adminEmail = "urdumonsta@gmail.com";
const adminPassword = "admin123"; // simple demo password

function login() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const msg = document.getElementById('loginMsg');

  if (email === adminEmail && password === adminPassword) {
    document.getElementById('authSection').style.display = 'none';
    document.getElementById('adminPanel').style.display = 'block';
    msg.innerText = "Welcome Admin!";
  } else {
    msg.innerText = "Logged in as viewer (no upload access).";
    document.getElementById('authSection').style.display = 'none';
  }
  displayContent();
}

function uploadContent() {
  const videoUrl = document.getElementById('videoUrl').value;
  const postContent = document.getElementById('postContent').value;

  if (videoUrl) {
    videos.push(videoUrl);
    localStorage.setItem('videos', JSON.stringify(videos));
    document.getElementById('videoUrl').value = '';
  }
  if (postContent) {
    posts.push(postContent);
    localStorage.setItem('posts', JSON.stringify(posts));
    document.getElementById('postContent').value = '';
  }

  displayContent();
}

function displayContent() {
  const videoContainer = document.getElementById('videos');
  const postContainer = document.getElementById('posts');
  videoContainer.innerHTML = '';
  postContainer.innerHTML = '';

  videos.forEach(url => {
    const embedUrl = url.replace('watch?v=', 'embed/');
    videoContainer.innerHTML += `<div class="video-item"><iframe src="${embedUrl}" allowfullscreen></iframe></div>`;
  });

  posts.forEach(text => {
    postContainer.innerHTML += `<div class="post-item">${text}</div>`;
  });
}